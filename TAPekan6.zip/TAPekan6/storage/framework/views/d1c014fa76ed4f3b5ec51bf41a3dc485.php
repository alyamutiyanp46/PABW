
<?php $__env->startSection('title', 'Login - LaporBanjir'); ?>

<?php $__env->startSection('content'); ?>
<div class="form-card">
    <h2>Login Akun</h2>
    <p class="form-subtitle">Masuk untuk mengelola laporan</p>

    <form action="<?php echo e(route('login')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required autofocus>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit">Login</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\PABW\TAPekan6\resources\views/auth/login.blade.php ENDPATH**/ ?>